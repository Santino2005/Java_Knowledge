package edu.austral.dissis.tictactoe;

public enum Symbol {
  // Eks
  X,
  // Circle
  O,
  // Empty
  Empty
}
